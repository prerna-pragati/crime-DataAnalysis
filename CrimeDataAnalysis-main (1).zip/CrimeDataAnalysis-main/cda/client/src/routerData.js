/* const lm = [
    {
        title: ,
        description: ,
    }
] 
*/
const gp = [
    {
        title: 'Crime rate per capita by State and Crime type',
        description: 'When the general public wants to know the crime stats, when they are deciding to relocate, this query will show the crime stats. Further, the general public can filter them by '
    }
]